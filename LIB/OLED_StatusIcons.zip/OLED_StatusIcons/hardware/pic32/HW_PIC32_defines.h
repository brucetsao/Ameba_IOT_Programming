// *** Hardwarespecific defines ***
#define PROGMEM
#define imagedatatype const unsigned char

