// *** Hardwarespecific defines ***
#define PROGMEM
#define imagedatatype const unsigned char

#define sei() interrupts()
#define cli() noInterrupts()
