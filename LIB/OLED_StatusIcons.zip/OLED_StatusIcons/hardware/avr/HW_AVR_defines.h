// *** Hardwarespecific defines ***
#define imagedatatype const uint8_t
